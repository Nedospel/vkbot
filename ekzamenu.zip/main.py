import dejurnue
import raspisanie
import vkmessage
import datetime
import time
import functools
from oken import yandexapi_key
import ekzamenu
import schedule
from multiprocessing import *
import imageproc


def main():
    imageproc.text('schoolbot.png', 'devnote.png')
    datue=ekzamenu.ekzamen()
#     messages = f'''
#     \n Доброе утро! \n Сегодня дежурит - {dejurnue.send_names(number_parta)}. \n До экзаменов осталось: \n {datue}
# '''
    messages = ''
    vkmessage.send_utro("3", messages)

schedule.every().day.at("03:30").do(main)
while True:
    schedule.run_pending()
    time.sleep(1)




