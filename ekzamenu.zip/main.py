import dejurnue
import raspisanie
import vkmessage
import datetime
import time
import functools
from oken import yandexapi_key
import ekzamenu


def main():
    f = open('number_parta.txt', 'r+')
    number_parta = int(f.read())
    f.seek(0)
    if str(number_parta) == "14":
        f.truncate()
        f.write("1")
        f.close()
    else:
        f.truncate()
        f.write(str(number_parta + 1))
        f.close()
    today = datetime.datetime.today().isoweekday()
    datue=ekzamenu.ekzamen()
    messages = f'''
    \n Доброе утро! \n Сегодня дежурит - {dejurnue.send_names(number_parta)}. \n До экзаменов осталось: \n {datue}
'''
    vkmessage.send_utro("1", messages, "")

main()





