import vk_api
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
from oken import token_group, id_group

def send_utro(id, message):
    vk_session = vk_api.VkApi(token = token_group)
    longpoll = VkBotLongPoll(vk_session, id_group)
    upload = vk_api.VkUpload(vk_session)
    photo = upload.photo_messages('devnote.png')
    owner_id = photo[0]['owner_id']
    photo_id = photo[0]['id']
    access_key = photo[0]['access_key']
    attachment = f'photo{owner_id}_{photo_id}_{access_key}'
    vk_session.method('messages.send', {'chat_id' : id, "message": message,
"attachment": attachment, "random_id": 0})

