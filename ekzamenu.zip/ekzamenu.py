import datetime
def ekzamen():
    now = datetime.datetime.today()
    geo_litra_ximia= datetime.datetime(2022,5,26)
    russkiy = datetime.datetime(2022,5,30)
    profil = datetime.datetime(2022,6,2)
    baza = datetime.datetime(2022,6,3)
    istoria_fiz = datetime.datetime(2022,6,6)
    objestvo = datetime.datetime(2022,6,9)
    inostrannue = datetime.datetime(2022,6,14)
    infa = datetime.datetime(2022,6,20)
    def r(b):
        l = b - now
        l = str(l).split(' ')
        l = l[0]
        # l += ' дней'
        return l
    # print(r(inostrannue))
    # a = f"""
    # Химия, литература - {r(geo_litra_ximia)}
    # Русский язык - {r(russkiy)}
    # Профильная матеша - {r(profil)}
    # Базовая матеша - {r(baza)}
    # Физика, история - {r(istoria_fiz)}
    # Обществознание - {r(objestvo)}
    # Биология, иностранные языки - {r(inostrannue)}
    # Информатика - {r(infa)}
    # """
    # return a
    return r(geo_litra_ximia),r(russkiy),r(profil),r(baza),r(istoria_fiz),r(objestvo),r(inostrannue),r(infa)


    
