import ekzamenu
import dejurnue


from PIL import Image, ImageDraw, ImageFont
def text(input_image_path, output_path):
    t_1 = ekzamenu.ekzamen()[0]
    t_2 = ekzamenu.ekzamen()[1]
    t_3 = ekzamenu.ekzamen()[2]
    t_4 = ekzamenu.ekzamen()[3]
    t_5 = ekzamenu.ekzamen()[4]
    t_6 = ekzamenu.ekzamen()[5]
    t_7 = ekzamenu.ekzamen()[6]
    t_8 = ekzamenu.ekzamen()[7]
    f = open('number_parta.txt', 'r+')
    number_parta = int(f.read())
    f.seek(0)
    if str(number_parta) == "14":
        f.truncate()
        f.write("1")
        f.close()
    else:
        f.truncate()
        f.write(str(number_parta + 1))
        f.close()
    dejuryat = dejurnue.send_names(number_parta)
    image = Image.open(input_image_path)
    draw = ImageDraw.Draw(image)
    font = ImageFont.truetype("inter-bold.ttf", size=70)
    text = dejuryat
    draw.multiline_text((30, 130), text, font=font, fill='#f9a36f')
    font = ImageFont.truetype("inter-bold.ttf", size=57)
    text = t_1
    draw.multiline_text((505, 414), text, font=font, fill='#87aaf8')
    text = t_2
    draw.multiline_text((382, 471), text, font=font, fill='#87aaf8')
    text = t_3
    draw.multiline_text((545, 530), text, font=font, fill='#87aaf8')
    text = t_4
    draw.multiline_text((440, 590), text, font=font, fill='#87aaf8')
    text = t_5
    draw.multiline_text((448, 647), text, font=font, fill='#87aaf8')
    text = t_6
    draw.multiline_text((465, 704), text, font=font, fill='#87aaf8')
    text = t_7
    draw.multiline_text((760, 763), text, font=font, fill='#87aaf8')
    text = t_8
    draw.multiline_text((389, 822), text, font=font, fill='#87aaf8')
    image.save(output_path)
